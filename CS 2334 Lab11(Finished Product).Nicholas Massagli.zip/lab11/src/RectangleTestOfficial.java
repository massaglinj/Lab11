import java.awt.Color;
import java.awt.Point;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test cases for the Rectangle
 * 
 * @author Stephen
 * @version 2018-04-02
 * Lab 11
 */
public class RectangleTestOfficial
{
    // implement this.
    private Rectangle r1 = new Rectangle(new Point(100, 100), 50, 100, Color.BLACK, true);
    private Rectangle r2 = new Rectangle(new Point(100, 100), 70, 50, Color.CYAN, false);
    
    private Square s1 = new Square(new Point(200, 300), 60, Color.BLUE, true);
    private Square s2 = new Square(new Point(200, 300), 70, Color.RED, false);
    @Test
    public void testRectangleConstructorPoint()
    {
     // Verify the quantity of points for each shape
        Assert.assertEquals("Quantity of points defining the Rectangle is more than 4", 4, r1.getLocation().length);
        Assert.assertEquals("Quantity of points defining the Rectangle is more than 4", 4, r2.getLocation().length);
        Assert.assertEquals("Quantity of points defining the Square is more than 4", 4, s1.getLocation().length);
        Assert.assertEquals("Quantity of points defining the Square is more than 4", 4, s2.getLocation().length);

        // Verify the locations for each shape
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(75,150), r1.getLocation()[0]);
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(65,125), r2.getLocation()[0]);
        Assert.assertEquals("Incorrect point for the Square", new Point(170,330), s1.getLocation()[0]);
        Assert.assertEquals("Incorrect point for the Square", new Point(165,335), s2.getLocation()[0]);
        
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(75,50), r1.getLocation()[1]);
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(65,75), r2.getLocation()[1]);
        Assert.assertEquals("Incorrect point for the Square", new Point(170,270), s1.getLocation()[1]);
        Assert.assertEquals("Incorrect point for the Square", new Point(165,265), s2.getLocation()[1]);
        
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(125,50), r1.getLocation()[2]);
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(135,75), r2.getLocation()[2]);
        Assert.assertEquals("Incorrect point for the Square", new Point(230,270), s1.getLocation()[2]);
        Assert.assertEquals("Incorrect point for the Square", new Point(235,265), s2.getLocation()[2]);
        
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(125,150), r1.getLocation()[3]);
        Assert.assertEquals("Incorrect point for the Rectangle", new Point(135,125), r2.getLocation()[3]);
        Assert.assertEquals("Incorrect point for the Square", new Point(230,330), s1.getLocation()[3]);
        Assert.assertEquals("Incorrect point for the Square", new Point(235,335), s2.getLocation()[3]);

        // Verify the colors for each shape
        Assert.assertEquals("Incorrect color for the Rectangle", Color.BLACK, r1.getColor());
        Assert.assertEquals("Incorrect color for the Rectangle", Color.CYAN, r2.getColor());
        Assert.assertEquals("Incorrect color for the Square", Color.BLUE, s1.getColor());
        Assert.assertEquals("Incorrect color for the Square", Color.RED, s2.getColor());
        
        // Verify the appropriate filled flag for each shape
        Assert.assertTrue("Incorrect flag for filled for the Rectangle", r1.isFilled());
        Assert.assertFalse("Incorrect flag for filled for the Rectangle", r2.isFilled());
        Assert.assertTrue("Incorrect flag for filled for the Square", s1.isFilled());
        Assert.assertFalse("Incorrect flag for filled for the Square", s2.isFilled());
    }
}
