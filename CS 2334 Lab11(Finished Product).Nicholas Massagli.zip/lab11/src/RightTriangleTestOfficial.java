
import java.awt.Color;
import java.awt.Point;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test cases for the Triangle
 * 
 * @author Stephen
 * @version 2018-04-02
 * Lab 11
 */
public class RightTriangleTestOfficial
{
    private RightTriangle t1 = new RightTriangle(new Point(100, 100), 50, 100, Color.BLACK, true);
    private RightTriangle t2 = new RightTriangle(new Point(100, 100), 75, 50, Color.CYAN, false);
    
    @Test
    public void testRightTriangleConstructorPoint()
    {
        // Verify the quantity of points for each shape
        Assert.assertEquals("Quantity of points defining the Right Triangle is more than 3", 3, t1.getLocation().length);
        Assert.assertEquals("Quantity of points defining the Right Triangle is more than 3", 3, t2.getLocation().length);
       
        // Verify the locations for each shape
        Assert.assertEquals("Incorrect point for the Right Triangle", new Point(100,100), t1.getLocation()[0]);
        Assert.assertEquals("Incorrect point for the Right Triangle", new Point(100,100), t2.getLocation()[0]);
        Assert.assertEquals("Incorrect point for the Right Triangle", new Point(100,200), t1.getLocation()[1]);
        Assert.assertEquals("Incorrect point for the Right Triangle", new Point(100,150), t2.getLocation()[1]);
        Assert.assertEquals("Incorrect point for the Right Triangle", new Point(150,100), t1.getLocation()[2]);
        Assert.assertEquals("Incorrect point for the Right Triangle", new Point(175,100), t2.getLocation()[2]);

        // Verify the colors for each shape
        Assert.assertEquals("Incorrect color for the Right Triangle", Color.BLACK, t1.getColor());
        Assert.assertEquals("Incorrect color for the Right Triangle", Color.CYAN, t2.getColor());
        
        // Verify the appropriate filled flag for each shape
        Assert.assertTrue("Incorrect flag for filled for the Right Triangle", t1.isFilled());
        Assert.assertFalse("Incorrect flag for filled for the Right Triangle", t2.isFilled());
        
    }
}
