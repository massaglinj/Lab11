
import java.awt.Color;
import java.awt.Point;

import javax.swing.JFrame;

/**
 * This class extends JFrame and contains the main entry point for the program.
 * 
 * @author CS2334. Modified by: Stephen
 * @version 2018-04-02
 * Lab 11
 */
public class DrawFrame extends JFrame
{
    /**
     * Serial ID
     */
    private static final long serialVersionUID = 1L;
    
    /** Contains and draws all the shapes */
    private static DrawPanel drawPanel;

    /**
     * Creates an invisible window, the objects to be drawn and adds them to the panel.
     * 
     * @param title String title of the drawing window
     */
    public DrawFrame(String title)
    {
        super(title);
        
        int width = 800;
        int height = 600;
        
        // draw a cat
        
        // Base head:
        Circle base = new Circle(new Point(300, 200), 200, Color.GRAY, true);
        
        // OutLine
        Circle outline = new Circle(new Point(92, 18), 600, Color.BLACK, false);
        // Mouth
        PolyLine mouth1 = new PolyLine(new Point(370, 320), new Point(400, 345), 20, Color.BLACK, true);
        PolyLine mouth2 = new PolyLine(new Point(400, 345), new Point(430, 320), 20, Color.BLACK, true);
        
        // Tongue
        Oval tongue = new Oval(new Point(405, 345), 15, 25, Color.RED, true);

        // Ears:
        RightTriangle ear1 = new RightTriangle(new Point(450,220), -25, -75, Color.PINK, true);
        RightTriangle ear2 = new RightTriangle(new Point(350,220), 25, -75, Color.PINK, true);
        RightTriangle ear3 = new RightTriangle(new Point(455,220), -45, -95, Color.GRAY, true);
        RightTriangle ear4 = new RightTriangle(new Point(345,220), 45, -95, Color.GRAY, true);
        
        // Eyes:
        Oval eye1 = new Oval(new Point (350, 245), 20, 30, Color.WHITE, true);
        Oval eye2 = new Oval(new Point (435, 245), 20, 30, Color.WHITE, true);
        Oval eye3 = new Oval(new Point (355, 250), 10, 20, Color.BLACK, true);
        Oval eye4 = new Oval(new Point (440, 250), 10, 20, Color.BLACK, true);
        
        // Nose and Whiskers(the pdf doesnt say anything about whiskers?):
        Circle nose = new Circle(new Point(389, 300), 20, Color.BLACK, true);
        
        // Collar:
        Oval collar = new Oval(new Point (326, 400), 160, 20, Color.BLUE, true);
        Circle button = new Circle(new Point(391,398), 34, Color.RED, true);
        Circle accent = new Circle(new Point(398,404), 20, Color.GREEN, false);
        
        // Square around the dog:
        Square border = new Square(new Point(395, 300), 400, Color.MAGENTA, false);

        // initialize the panel and add the shapes to it
        drawPanel = new DrawPanel();
        
        // add shapes to the panel:
        drawPanel.addShape(base);
        drawPanel.addShape(ear3);
        drawPanel.addShape(ear4);
        drawPanel.addShape(ear1);
        drawPanel.addShape(ear2);
        drawPanel.addShape(eye1);
        drawPanel.addShape(eye2);
        drawPanel.addShape(eye3);
        drawPanel.addShape(eye4);
        drawPanel.addShape(nose);
        drawPanel.addShape(border);
        drawPanel.addShape(collar);
        drawPanel.addShape(button);
        drawPanel.addShape(accent);
        drawPanel.addShape(mouth1);
        drawPanel.addShape(mouth2);
        drawPanel.addShape(outline);
        drawPanel.addShape(tongue);
        
        // set background color
        drawPanel.setBackground(Color.CYAN);
        
        // add panel to frame
        this.add(drawPanel);
        
        // finish setting up the frame
        setSize(width, height);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * The main method, initializes the frame to draw the images.
     * 
     * @param args Command line arguments.
     */
    public static void main(String[] args)
    {
        DrawFrame frame = new DrawFrame("Woof :3");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
