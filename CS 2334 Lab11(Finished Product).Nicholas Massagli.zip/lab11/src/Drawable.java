import java.awt.Graphics;

public abstract interface Drawable
{
    public void draw(Graphics g);
}
